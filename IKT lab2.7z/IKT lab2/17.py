n = int(input())
a = [int(i) for i in input().split()]
a = set(a)
print(len(a))