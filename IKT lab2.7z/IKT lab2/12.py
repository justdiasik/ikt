n=int(input())
i=1
while i<n:
    print(i)
    i*=2