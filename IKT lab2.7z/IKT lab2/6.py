n = int(input("horizontal blocks: "))
m = int(input("horizontal blocks:"))
k = int(input("how much? "))
if k < n * m and ((k % n == 0) or (k % m == 0)):
    print('YES')
else:
    print('NO')