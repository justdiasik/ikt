sum = 0
n = int(input())
while n!=0:
    sum += n
    n = int(input())
print(sum)