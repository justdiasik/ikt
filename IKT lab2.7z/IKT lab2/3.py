x1 = int(input("elephant x coordinate: "))
y1 = int(input("elephant y coordinate: "))
x2 = int(input("place x coordinate: "))
y2 = int(input("place y coordinate: "))

def elephant_walks(x1, y1, x2, y2):
    if abs(x1-x2)==abs(y1-y2) and x1 and x2 and y1 and y2 <= 8:
        return True
    else: return False

if elephant_walks(x1, y1, x2, y2):
    print("Yes")
    
else: print("No")