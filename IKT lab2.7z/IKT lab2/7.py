n = int(input("long side is: "))
m = int(input("short side is: "))
x = int(input("range to long side: "))
y = int(input("range to short side: "))

def way_to_escape(n, m, x, y):
    x_min = abs(x-n)
    y_min = abs(y-m)
    if x_min > x:
        x_min = x
    if y_min > y:
        y_min = y
    print(min(x_min, y_min))
    
way_to_escape(n, m, x, y)