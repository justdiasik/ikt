a_1 = int(input())
b_1 = int(input())
c_1 = int(input())

a_2 = int(input())
b_2 = int(input())
c_2 = int(input())

v_1 = a_1 * b_1 * c_1
v_2 = a_2 * b_2 * c_2

if v_1 == v_2:
    print("Boxes are equal")
    
elif v_1 > v_2:
    print("the first box is larger than the second one")

elif v_1 < v_2:
    print("the first box is smaller than the second one")
    
else: print("Boxes are incomparable")