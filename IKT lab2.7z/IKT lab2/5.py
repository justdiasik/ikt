x1 = int(input("horse x coordinate: "))
y1 = int(input("horse y coordinate: "))
x2 = int(input("place x coordinate: "))
y2 = int(input("place y coordinate: "))

def horse_walk_h(x1, y1, x2, y2):
    if abs(x1-x2) == 2 and abs(y1-y2) == 1 and x1 and x2 and y1 and y2 <= 8:
        return True
    else: return False
    
def horse_walk_v(x1, y1, x2, y2):
    if abs(x1-x2) == 1 and abs(y1-y2) == 2 and x1 and x2 and y1 and y2 <= 8:
        return True
    else: return False
    
if horse_walk_h(x1, y1, x2, y2) or horse_walk_v(x1, y1, x2, y2):
    print("Yes")
    
else: print("No")